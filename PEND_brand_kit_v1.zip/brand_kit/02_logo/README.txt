P·E·N·D house — Логотип SVG
=============================
Майстер-аркуш: PEND_logo_FINAL_sheet_v27.pdf
Текст у кривих. Розфокус і glow — нативні SVG-фільтри.

ФАЙЛИ — 15 варіантів
---------------------

ДВОРЯДКОВІ (P·E·N·D / house) — еталонна висота полотна
  PEND_2row_red_glow_on-dark.svg      — ОСНОВНИЙ. Червона щілина + glow, на темному
  PEND_2row_red_rozfokus_on-dark.svg  — Червона щілина + розфокус, на темному
  PEND_2row_red_rozfokus_on-light.svg — Червона щілина + розфокус, на світлому
  PEND_2row_brass_glow_on-dark.svg    — Латунна щілина + glow, на темному
  PEND_2row_brass_rozfokus_on-dark.svg  — Латунна щілина + розфокус, на темному
  PEND_2row_brass_rozfokus_on-light.svg — Латунна щілина + розфокус, на світлому
  PEND_2row_no-keyhole_on-dark.svg    — Без щілини, на темному
  PEND_2row_no-keyhole_on-light.svg   — Без щілини, на світлому

ОДНОРЯДКОВІ (P·E·N·D — одним рядком)
  PEND_1row_red_rozfokus_on-dark.svg  — Червона щілина + розфокус, на темному
  PEND_1row_red_rozfokus_on-light.svg — Червона щілина + розфокус, на світлому
  PEND_1row_brass_rozfokus_on-dark.svg  — Латунна щілина + розфокус, на темному
  PEND_1row_brass_rozfokus_on-light.svg — Латунна щілина + розфокус, на світлому
  PEND_1row_no-keyhole_on-dark.svg    — Без щілини, на темному
  PEND_1row_no-keyhole_on-light.svg   — Без щілини, на світлому

РОЗШИРЕНИЙ LOCKUP
  PEND_full_lockup.svg  — P·E·N·D + house + hush bar + слоган + KYIV + рамка

ІЄРАРХІЯ ЗАСТОСУВАННЯ
----------------------
1. PEND_2row_red_glow_on-dark    — основний носій, цифровий
2. PEND_2row_red_rozfokus_on-dark — альтернатива без glow
3. PEND_1row_*                   — горизонтальні компоновки (шапка сайту, підпис)
4. *_on-light                    — тільки на кремовому/світлому тлі
5. *_brass_*                     — тиснення, особливі носії
6. *_no-keyhole_*                — мінімальна версія (дрібний розмір, монохром)
7. PEND_full_lockup              — офіційні документи, вивіска, брендинг простору

ПРАВИЛА
-------
· Крапки (·) — ТІЛЬКИ між літерами P·E·N·D, НІКОЛИ після D
· Glow — тільки на дворядковому логотипі
· Розмір літер P·E·N·D однаковий у дворядковому й однорядковому варіантах
· Не деформувати пропорції
· Не змінювати кольори елементів
· Мінімальний відступ навколо лого — висота букви H з кожного боку
